export class SkuUsageCount {
  public sku: string;
  public skuUsageCount: number;
  public skuUsageFormats: string;
  public skuUsageFilterInOut: string;
}

