export class FormatCompose {
  public id: number;
  public fcFormatKey: string;
  public fcRow: number;
  public fcPart1: string;
  public fcPart2: string;
  public fcPart3: string;
  public fcContentOrText: string;
}
