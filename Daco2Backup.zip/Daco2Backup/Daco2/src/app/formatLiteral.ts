export class FormatLiteral {
  public id: number;
  public flContent: string;
  public flText: string;
  public flFilterInOut: string;
} 