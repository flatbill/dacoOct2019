export class FormatUsageCount {
  public formatNumber: string;
  public formatUsageCount: number;
}

