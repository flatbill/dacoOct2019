export class FormatMask {
  public id: number;
  public fmMaskType: string;
  public fmMask: string;
  public fmFilterInOut: string;
}