export class ContentChoice {    
        public id: number; 
        public contentName: string; 
        public contentType: string;
        public contentMask: string;
        public contentUsageCount: number;
  } 