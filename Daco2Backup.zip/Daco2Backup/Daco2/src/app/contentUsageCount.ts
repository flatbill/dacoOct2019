export class ContentUsageCount {
  public contentName: string;
  public contentUsageCount: number;
}

