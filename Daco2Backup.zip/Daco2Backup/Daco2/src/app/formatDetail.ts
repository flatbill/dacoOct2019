export class FormatDetail {
  public id: number;
  public fdRow: number;
  public fdRowSlot: number;
  public fdFormatKey: string;
  public fdContentName: string;
  public fdMask: string;
  public fdFilterInOut: string;
}