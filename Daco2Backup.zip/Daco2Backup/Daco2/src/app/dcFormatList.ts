export class DcFormatListItem {
        public id: number;
        public dfFormatKey: string;
        public dfFormatName: string;
        public dfFormatDesc: string;
        public dfFilterInOut: string;
        public dfUsageCount: number;

  }
