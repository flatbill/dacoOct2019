export class SkuFormat {
  public id: number;
  public sfSku: string;
  public sfLayer: string;
  public sfFormatKey: string;
  public sfFilterInOut: string;
}
