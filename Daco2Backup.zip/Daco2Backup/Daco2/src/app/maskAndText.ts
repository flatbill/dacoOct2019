export class MaskAndText {
  public id: number;
  public mtContent: string;
  public mtMaskOrText: string;
  public mtMorT: string;
}
